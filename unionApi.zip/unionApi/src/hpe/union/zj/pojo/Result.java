package hpe.union.zj.pojo;

import java.util.List;

public class Result {

	private String status;
	private List<String> messages;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<String> getMessages() {
		return messages;
	}
	public void setMessages(List<String> messages) {
		this.messages = messages;
	}
	
	
}
